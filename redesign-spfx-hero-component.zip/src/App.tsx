import * as React from "react";
import HomeHero from "./components/HomeHero";
import { DEMO_KPIS, DEMO_SLIDES } from "./components/homeLayout";

const NAV = [
  { label: "Accueil", href: "#accueil" },
  { label: "Formations", href: "#formations" },
  { label: "Ressources", href: "#ressources" },
  { label: "Événements", href: "#evenements" },
];

export default function App() {
  const scrollToHash = (href: string): void => {
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const onInternalNavigate = (
    event: React.MouseEvent<HTMLAnchorElement>,
    href: string,
  ): void => {
    if (href.startsWith("#")) {
      event.preventDefault();
      scrollToHash(href);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <header className="absolute inset-x-0 top-0 z-30">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5 sm:px-10">
          <a
            href="#accueil"
            onClick={(e) => onInternalNavigate(e, "#accueil")}
            className="flex items-center gap-3 text-white"
          >
            <span className="grid h-9 w-9 place-items-center rounded-lg bg-bbi-gold font-display text-sm font-extrabold text-bbi-950">
              BB
            </span>
            <span className="hidden font-display text-sm font-bold tracking-wide sm:block">
              Business Builders International
            </span>
          </a>
          <nav className="hidden items-center gap-1 md:flex" aria-label="Navigation principale">
            {NAV.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={(e) => onInternalNavigate(e, item.href)}
                className="rounded-full px-4 py-2 text-sm font-medium text-white/80 transition hover:bg-white/10 hover:text-white"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main>
        <HomeHero
          slides={DEMO_SLIDES}
          eyebrow="Business Builders International"
          title=""
          subtitle=""
          imageUrl=""
          primaryLabel="Découvrir"
          primaryUrl="#formations"
          secondaryLabel="Voir les ressources"
          secondaryUrl="#ressources"
          kpis={DEMO_KPIS}
          compact={false}
          greeting="Bonjour Camille"
          onExplore={() => scrollToHash("#formations")}
          onInternalNavigate={onInternalNavigate}
        />

        {[
          { id: "formations", title: "Formations", text: "Le catalogue des formations apparaîtra ici." },
          { id: "ressources", title: "Ressources", text: "Guides, modèles et outils du groupe." },
          { id: "evenements", title: "Événements", text: "Les prochains rendez-vous BBI." },
        ].map((s) => (
          <section key={s.id} id={s.id} className="mx-auto max-w-7xl scroll-mt-6 px-6 py-24 sm:px-10">
            <h2 className="font-display text-3xl font-extrabold tracking-tight text-bbi-900">{s.title}</h2>
            <p className="mt-3 text-slate-500">{s.text}</p>
          </section>
        ))}
      </main>
    </div>
  );
}
