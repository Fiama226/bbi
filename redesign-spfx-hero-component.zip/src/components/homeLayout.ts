/** Diapositive du carrousel « À la une ». */
export interface IHeroSlide {
  imageUrl?: string;
  eyebrow?: string;
  /** Les retours à la ligne (\n) sont conservés dans le titre. */
  title?: string;
  subtitle?: string;
  ctaLabel?: string;
  ctaUrl?: string;
}

/** Chiffre clé affiché sous le carrousel. */
export interface IKpi {
  value: string;
  label: string;
}

export const DEMO_SLIDES: IHeroSlide[] = [
  {
    imageUrl:
      "https://images.pexels.com/photos/7648050/pexels-photo-7648050.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1800",
    eyebrow: "Académie BBI · Rentrée 2026",
    title: "Développez les compétences\nqui font grandir vos équipes",
    subtitle:
      "Plus de 120 formations certifiantes, animées par des experts du terrain, pour accompagner chaque étape de votre parcours professionnel.",
    ctaLabel: "Découvrir les formations",
    ctaUrl: "#formations",
  },
  {
    imageUrl:
      "https://images.pexels.com/photos/18999482/pexels-photo-18999482.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1800",
    eyebrow: "Communauté",
    title: "Un réseau de 40 pays,\nune même ambition",
    subtitle:
      "Rejoignez les cercles d'échange, partagez vos retours d'expérience et inspirez-vous des meilleures pratiques du groupe.",
    ctaLabel: "Rejoindre la communauté",
    ctaUrl: "#ressources",
  },
  {
    imageUrl:
      "https://images.pexels.com/photos/7648045/pexels-photo-7648045.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1800",
    eyebrow: "Événement",
    title: "Convention annuelle BBI",
    subtitle:
      "Trois jours de conférences, d'ateliers et de rencontres pour célébrer nos réussites et dessiner la feuille de route à venir.",
    ctaLabel: "Réserver ma place",
    ctaUrl: "#evenements",
  },
  {
    // Sans image : le visuel BBI embarqué est utilisé.
    eyebrow: "Ressources",
    title: "Tout ce qu'il vous faut,\nau même endroit",
    subtitle:
      "Guides, modèles, procédures et outils : la bibliothèque de référence pour travailler plus vite et mieux.",
    ctaLabel: "Explorer les ressources",
    ctaUrl: "#ressources",
  },
];

export const DEMO_KPIS: IKpi[] = [
  { value: "120+", label: "Formations disponibles" },
  { value: "8 500", label: "Collaborateurs formés" },
  { value: "40", label: "Pays représentés" },
  { value: "96 %", label: "Taux de satisfaction" },
];
