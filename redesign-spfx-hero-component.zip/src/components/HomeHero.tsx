import * as React from "react";
import { IHeroSlide, IKpi } from "./homeLayout";

export interface IHomeHeroProps {
  /** Diapositives configurées dans le volet de propriétés. */
  slides: IHeroSlide[];
  /** Sur-titre global, utilisé quand la diapositive n'en définit pas. */
  eyebrow: string;
  /** Repli mono-diapositive (anciennes instances : propriétés heroTitle…). */
  title: string;
  subtitle: string;
  imageUrl: string;
  primaryLabel: string;
  primaryUrl: string;
  secondaryLabel: string;
  secondaryUrl: string;
  kpis: IKpi[];
  compact: boolean;
  /** Salutation « Bonjour Prénom » : vide = masquée. */
  greeting: string;
  onExplore: () => void;
  onInternalNavigate: (
    event: React.MouseEvent<HTMLAnchorElement>,
    href: string,
  ) => void;
}

const AUTOPLAY_MS = 8000;

/** Visuels BBI embarqués : utilisés quand la diapositive n'a pas d'image. */
const demoVisualClass = (index: number): string =>
  `visual-demo-${index % 4}`;

const prefersReducedMotion = (): boolean => {
  try {
    return (
      window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    );
  } catch {
    return false;
  }
};

const pad = (n: number): string => (n < 10 ? `0${n}` : String(n));

const ChevronLeft = (): React.ReactElement => (
  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M15 18l-6-6 6-6" />
  </svg>
);
const ChevronRight = (): React.ReactElement => (
  <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M9 18l6-6-6-6" />
  </svg>
);
const ArrowRight = (): React.ReactElement => (
  <svg viewBox="0 0 24 24" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M5 12h14M13 6l6 6-6 6" />
  </svg>
);
const ArrowDown = (): React.ReactElement => (
  <svg viewBox="0 0 24 24" className="h-4 w-4 animate-bounce" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M12 5v14M6 13l6 6 6-6" />
  </svg>
);

const arrowBtn =
  "grid h-11 w-11 place-items-center rounded-full border border-white/25 bg-white/10 text-white backdrop-blur-md transition hover:border-white/60 hover:bg-white/20 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-bbi-gold";

const HomeHero: React.FC<IHomeHeroProps> = (props) => {
  const {
    slides,
    eyebrow,
    title,
    subtitle,
    imageUrl,
    primaryLabel,
    primaryUrl,
    secondaryLabel,
    secondaryUrl,
    kpis,
    compact,
    greeting,
    onExplore,
    onInternalNavigate,
  } = props;

  /**
   * Diapositives effectives : la configuration détaillée gagne, sinon les
   * propriétés historiques (titre, accroche, image) forment une diapositive.
   */
  const carousel = React.useMemo<IHeroSlide[]>(() => {
    const configured = (slides || []).filter(
      (slide) => !!(slide.title || slide.imageUrl),
    );
    if (configured.length > 0) {
      return configured.map((slide) => ({
        ...slide,
        eyebrow: slide.eyebrow || eyebrow,
        ctaLabel: slide.ctaLabel || primaryLabel,
        ctaUrl: slide.ctaUrl || primaryUrl,
      }));
    }
    return [
      {
        imageUrl: imageUrl || "",
        eyebrow: eyebrow || "",
        title: title || "",
        subtitle: subtitle || "",
        ctaLabel: primaryLabel || "",
        ctaUrl: primaryUrl || "",
      },
    ];
  }, [slides, eyebrow, title, subtitle, imageUrl, primaryLabel, primaryUrl]);

  const [index, setIndex] = React.useState<number>(0);
  const [paused, setPaused] = React.useState<boolean>(false);
  const [animate, setAnimate] = React.useState<boolean>(true);
  const count = carousel.length;

  React.useEffect(() => {
    setAnimate(!prefersReducedMotion());
  }, []);

  // Défilement automatique : jamais pendant un survol, une prise de focus
  // ou un onglet en arrière-plan.
  React.useEffect(() => {
    if (count < 2 || paused || !animate) {
      return undefined;
    }
    const timer = window.setInterval(() => {
      if (!document.hidden) {
        setIndex((current) => (current + 1) % count);
      }
    }, AUTOPLAY_MS);
    return () => window.clearInterval(timer);
  }, [count, paused, animate]);

  React.useEffect(() => {
    if (index > count - 1) {
      setIndex(0);
    }
  }, [count, index]);

  const go = React.useCallback(
    (delta: number): void => {
      setIndex((current) => (current + delta + count) % count);
    },
    [count],
  );

  const safeIndex = Math.min(index, Math.max(0, count - 1));
  const active = carousel[safeIndex] || carousel[0];
  const titleLines = (active.title || "").split("\n");

  const onKeyDown = (event: React.KeyboardEvent<HTMLElement>): void => {
    if (event.key === "ArrowRight") {
      go(1);
    } else if (event.key === "ArrowLeft") {
      go(-1);
    }
  };

  return (
    <section
      className="relative bg-slate-50"
      id="accueil"
      data-bbi-view="accueil"
      data-bbi-block="hero"
      aria-roledescription="carrousel"
      aria-label="À la une — Business Builders International"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      onKeyDown={onKeyDown}
    >
      {/* ───────────── Scène ───────────── */}
      <div
        className={`relative isolate flex overflow-hidden bg-bbi-950 text-white ${
          compact ? "min-h-[440px]" : "min-h-[600px] lg:min-h-[700px]"
        }`}
        data-bbi-hero-stage="true"
      >
        {/* Médias */}
        {carousel.map((slide, slideIndex) => {
          const isActive = slideIndex === safeIndex;
          return (
            <div
              key={`media-${slideIndex}`}
              className={`absolute inset-0 -z-30 transition-opacity duration-1000 ease-in-out ${
                isActive ? "opacity-100" : "opacity-0"
              }`}
              data-bbi-hero-slide={slideIndex}
              aria-hidden="true"
            >
              <div
                className={`absolute inset-0 bg-cover bg-center will-change-transform ${
                  animate
                    ? isActive
                      ? "scale-110 transition-transform duration-[12000ms] ease-out"
                      : "scale-100 transition-transform duration-1000"
                    : ""
                } ${slide.imageUrl ? "" : demoVisualClass(slideIndex)}`}
                style={
                  slide.imageUrl
                    ? { backgroundImage: `url("${slide.imageUrl}")` }
                    : undefined
                }
              />
              {!slide.imageUrl && (
                <div className="visual-grid absolute inset-0" />
              )}
            </div>
          );
        })}

        {/* Voiles : lisibilité du texte */}
        <div
          className="absolute inset-0 -z-20 bg-gradient-to-r from-bbi-950/95 via-bbi-950/70 to-bbi-950/10"
          aria-hidden="true"
        />
        <div
          className="absolute inset-0 -z-20 bg-gradient-to-t from-bbi-950/80 via-transparent to-bbi-950/30"
          aria-hidden="true"
        />

        {/* Contenu */}
        <div
          className={`mx-auto flex w-full max-w-7xl flex-col justify-center px-6 sm:px-10 ${
            compact ? "pb-28 pt-12" : "pb-40 pt-20 lg:pb-44 lg:pt-24"
          }`}
        >
          {greeting && (
            <p className="mb-6 inline-flex w-fit items-center gap-2 rounded-full border border-white/20 bg-white/10 py-1.5 pl-2 pr-4 text-sm font-medium text-white/90 backdrop-blur-md">
              <span className="grid h-6 w-6 place-items-center rounded-full bg-white/15 text-sm" aria-hidden="true">
                👋
              </span>
              {greeting}
            </p>
          )}

          <div
            key={`slide-${safeIndex}`}
            className={`max-w-3xl ${animate ? "hero-text-anim" : ""}`}
          >
            <p className="flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.2em] text-bbi-gold sm:text-[13px]">
              <span className="h-px w-8 bg-bbi-gold" aria-hidden="true" />
              {active.eyebrow || "Business Builders International"}
            </p>

            {active.title ? (
              <h1
                id="bbi-home-title"
                className={`mt-5 font-display font-extrabold leading-[1.05] tracking-tight text-white ${
                  compact
                    ? "text-3xl sm:text-4xl lg:text-5xl"
                    : "text-4xl sm:text-5xl lg:text-6xl xl:text-[4.25rem]"
                }`}
              >
                {titleLines.map((line, lineIndex) => (
                  <React.Fragment key={`${line}-${lineIndex}`}>
                    {line}
                    {lineIndex < titleLines.length - 1 && <br className="hidden sm:block" />}
                    {lineIndex < titleLines.length - 1 && <span className="sm:hidden"> </span>}
                  </React.Fragment>
                ))}
              </h1>
            ) : (
              <span />
            )}

            {active.subtitle ? (
              <p className="mt-6 max-w-2xl text-base leading-relaxed text-white/80 sm:text-lg">
                {active.subtitle}
              </p>
            ) : (
              <span />
            )}

            <div className="mt-9 flex flex-wrap items-center gap-3 sm:gap-4">
              {active.ctaLabel && (
                <a
                  className="group inline-flex items-center gap-2.5 rounded-full bg-bbi-gold px-7 py-3.5 text-sm font-bold text-bbi-950 shadow-lg shadow-black/20 transition hover:-translate-y-0.5 hover:bg-[#ffc95f] hover:shadow-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                  href={active.ctaUrl || "#formations"}
                  onClick={(event) => {
                    onInternalNavigate(event, active.ctaUrl || "#formations");
                  }}
                >
                  {active.ctaLabel}
                  <ArrowRight />
                </a>
              )}
              {secondaryLabel && (
                <a
                  className="inline-flex items-center rounded-full border border-white/30 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white backdrop-blur-md transition hover:border-white/70 hover:bg-white/15 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
                  href={secondaryUrl || "#ressources"}
                  onClick={(event) => {
                    onInternalNavigate(event, secondaryUrl || "#ressources");
                  }}
                >
                  {secondaryLabel}
                </a>
              )}
            </div>
          </div>
        </div>

        {/* Contrôles */}
        <div className="absolute inset-x-0 bottom-16 sm:bottom-20">
          <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-4 px-6 sm:px-10">
            {count > 1 ? (
              <div className="flex items-center gap-5">
                <p className="font-display text-sm font-bold tabular-nums tracking-wider text-white" aria-hidden="true">
                  {pad(safeIndex + 1)}
                  <span className="mx-1.5 text-white/40">/</span>
                  <span className="text-white/50">{pad(count)}</span>
                </p>
                <ul className="flex items-center gap-1" aria-label="Choix de la diapositive">
                  {carousel.map((slide, dotIndex) => {
                    const isActive = dotIndex === safeIndex;
                    return (
                      <li key={`dot-${dotIndex}`}>
                        <button
                          type="button"
                          className="group flex h-8 items-center px-1 focus-visible:outline-2 focus-visible:outline-bbi-gold"
                          aria-label={`Diapositive ${dotIndex + 1} sur ${count}${
                            slide.title ? ` : ${slide.title.replace(/\n/g, " ")}` : ""
                          }`}
                          aria-current={isActive ? "true" : undefined}
                          onClick={() => setIndex(dotIndex)}
                        >
                          <span
                            className={`relative block h-1 overflow-hidden rounded-full transition-all duration-500 ${
                              isActive
                                ? "w-14 bg-white/30"
                                : "w-6 bg-white/30 group-hover:bg-white/60"
                            }`}
                          >
                            {isActive && (
                              <span
                                key={`progress-${safeIndex}-${paused}`}
                                className={`absolute inset-0 rounded-full bg-bbi-gold ${
                                  animate && !paused ? "hero-progress" : ""
                                }`}
                                style={
                                  animate && !paused
                                    ? { animationDuration: `${AUTOPLAY_MS}ms` }
                                    : undefined
                                }
                              />
                            )}
                          </span>
                          <span className="sr-only">{dotIndex + 1}</span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
                <div className="hidden items-center gap-2 sm:flex">
                  <button type="button" className={arrowBtn} onClick={() => go(-1)} aria-label="Diapositive précédente">
                    <ChevronLeft />
                  </button>
                  <button type="button" className={arrowBtn} onClick={() => go(1)} aria-label="Diapositive suivante">
                    <ChevronRight />
                  </button>
                </div>
              </div>
            ) : (
              <span />
            )}

            <button
              type="button"
              className="hidden items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-white/80 transition hover:text-white focus-visible:outline-2 focus-visible:outline-bbi-gold md:inline-flex"
              onClick={onExplore}
              aria-label="Descendre dans la page"
            >
              Explorer <ArrowDown />
            </button>
          </div>
        </div>

        {/* Annonce aux lecteurs d'écran du changement de diapositive. */}
        <p className="sr-only" aria-live="polite">
          {`Diapositive ${safeIndex + 1} sur ${count}${
            active.title ? ` : ${active.title.replace(/\n/g, " ")}` : ""
          }`}
        </p>
      </div>

      {/* ───────────── Chiffres clés ───────────── */}
      {kpis.length > 0 && (
        <div className="relative z-10 mx-auto -mt-12 w-full max-w-7xl px-4 sm:-mt-14 sm:px-10">
          <ul
            className="flex flex-wrap overflow-hidden rounded-2xl bg-white shadow-[0_20px_50px_-15px_rgba(10,26,63,0.35)] ring-1 ring-slate-900/5 lg:flex-nowrap"
            data-bbi-kpi-band="true"
            aria-label="Chiffres clés BBI"
          >
            {kpis.map((kpi) => (
              <li
                key={`${kpi.value}-${kpi.label}`}
                className="group relative flex basis-1/2 flex-col justify-center gap-1 px-6 py-6 transition-colors hover:bg-slate-50 sm:px-8 lg:flex-1 lg:basis-0 lg:border-l lg:border-slate-100 lg:first:border-l-0"
              >
                <span
                  className="absolute left-6 top-0 h-[3px] w-8 rounded-b bg-bbi-gold transition-all duration-300 group-hover:w-14 sm:left-8"
                  aria-hidden="true"
                />
                <strong className="font-display text-3xl font-extrabold tracking-tight text-bbi-900 sm:text-4xl">
                  {kpi.value}
                </strong>
                <span className="text-sm font-medium text-slate-500">{kpi.label}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
};

export default HomeHero;
